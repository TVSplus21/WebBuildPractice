# PersonalFinanceApp - Backend

***Please, note that this repository is a replica of PK's private project in GitHub.***
***The open-source version was modified slightly and, as a result, might not build.***
***The app's no longer maintained is for reference only.***

PIRATE KING's personal finance app BACKEND

Tech Stack: 
- C#
- .net Core
- Plaid API
- Azure Cosmos DB
- Azure Cloud Apps (Functions, KeyVault, AppService, etc.)
