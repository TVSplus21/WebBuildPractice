﻿namespace PirateKing.Functions
{
    internal class Settings
    {
        public const string SyncAssetsSchedule = nameof(SyncAssetsSchedule);
        public const string StorageConnectionString = nameof(StorageConnectionString);
    }
}