﻿using System;

namespace PirateKing.Tokens
{
    public class TokenConstants
    {
        public static TimeSpan DefaultLifeSpan = TimeSpan.FromMinutes(60);
    }
}
