﻿namespace PirateKing.Configurations
{
    public class LocalEnvironmentDefinition //: EnvironmentDefinition
    {
    }
}
