﻿namespace PirateKing.Core
{
    public class TimeZones
    {
        public const string PacificStandardTime = "Pacific Standard Time";
    }
}
