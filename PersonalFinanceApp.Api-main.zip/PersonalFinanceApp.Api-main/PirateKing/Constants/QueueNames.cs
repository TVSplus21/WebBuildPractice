﻿using System;

namespace PirateKing.Constants
{
    public class QueueNames
    {
        public const string SyncTransactions = "sync-transactions-queue";
    }
}
