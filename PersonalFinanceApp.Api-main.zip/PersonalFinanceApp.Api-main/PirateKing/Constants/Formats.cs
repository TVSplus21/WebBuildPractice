﻿namespace PirateKing.Constants
{
    public class DateFormats
    {
        public const string DateYmd = "yyyy-MM-dd";
        public const string FullMonthName = "MMMM";
    }
}
