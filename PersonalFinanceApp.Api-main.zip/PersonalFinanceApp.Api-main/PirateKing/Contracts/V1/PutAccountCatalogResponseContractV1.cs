﻿namespace PirateKing.Contracts.V1
{
    /// <summary>
    /// Put Account Catalog Response Contract
    /// </summary>
    public class PutAccountCatalogResponseContractV1 : PutAccountCatalogRequestContractV1
    {
    }
}
